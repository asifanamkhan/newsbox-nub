@extends('front-end.layouts.master')
@section('content')
    @include('front-end.home-news.latest-news')
@endsection
