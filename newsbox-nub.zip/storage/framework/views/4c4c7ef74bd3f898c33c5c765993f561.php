<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('front-end.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
<!-- Topbar Start -->
<?php echo $__env->make('front-end.layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Topbar End -->


<!-- Navbar Start -->
<?php
    $news_categories = \Illuminate\Support\Facades\DB::table('news_categories')->get();
?>
<?php echo $__env->make('front-end.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Navbar End -->
<?php if(\Request::route()->getName() == 'home'): ?>
    <!-- Main News Slider Start -->
    <?php echo $__env->make('front-end.home-news.slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Main News Slider End -->

    <!-- Breaking News Start -->
    <?php echo $__env->make('front-end.home-news.breaking-news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Breaking News End -->

    <!-- Featured News Slider Start -->

    <?php echo $__env->make('front-end.home-news.featured', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<!-- Featured News Slider End -->

<!-- News With Sidebar Start -->
<div class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <div class="col-lg-4">
                <?php echo $__env->make('front-end.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<!-- News With Sidebar End -->


<!-- Footer Start -->
<?php echo $__env->make('front-end.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer End -->

<?php echo $__env->make('front-end.layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Back to Top -->
<a href="#" class="btn btn-primary btn-square back-to-top"><i class="fa fa-arrow-up"></i></a>

</body>

</html><?php /**PATH D:\laragon\www\newsbox-nub\resources\views/front-end/layouts/master.blade.php ENDPATH**/ ?>