
<?php $__env->startSection('content-header'); ?>
    <h1 style="font-family: 'Arial Narrow';">
        News
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-pie-chart"></i> Dashboard</a></li>
        <li class="active">news</li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-12">
                            <a target="_blank" href="<?php echo e(asset($news->image)); ?>">
                                <img class="img-fluid rounded img-thumbnail"
                                     src="<?php echo e(asset($news->image)); ?>" alt="User profile picture">
                            </a>
                        </div>
                        <div class="col-md-12">
                            <table class="table table-bordered table-striped" style="margin-top: 12px">
                                <tr>
                                    <th style="width: 20%">Title</th>
                                    <td style="width: 80%">
                                        <b style="color: orangered"><?php echo e($news->title); ?></b>
                                    </td>
                                </tr>
                                <tr>
                                    <th style="">Date</th>
                                    <td style=""><?php echo e($news->date); ?></td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        <?php if($news->status == 1): ?>
                                            <span class="badge badge-success" style="background: darkgreen">Active</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger" style="background: darkred">In Active</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th style="">Type</th>
                                    <td style=""><?php echo e($news->type_name); ?></td>
                                </tr>
                                <tr>
                                    <th style="">Category</th>
                                    <td style=""><?php echo e($news->category_name); ?></td>
                                </tr>
                                <tr>
                                    <th style="">View count</th>
                                    <td style=""><?php echo e($news->views_count ?? 0); ?></td>
                                </tr>
                                <tr>
                                    <th style="">Created By</th>
                                    <td style=""><?php echo e($news->created_user_name); ?></td>
                                </tr>

                            </table>
                        </div>
                    </div>

                </div>
                <div class="col-md-8">
                    <table class="table table-bordered">
                        <tr>
                            <th style="font-size: 20px">Description</th>
                        </tr>
                        <tr>
                            <td><?php echo $news->description; ?></td>
                        </tr>
                    </table>
                </div>
                <!-- /.col -->
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#side-news").addClass('active');
            $("#side-news-news").addClass('active');
            $("#side-news-news").addClass('active-sidebar');
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\newsbox-nub\resources\views/back-end/news/news/show.blade.php ENDPATH**/ ?>