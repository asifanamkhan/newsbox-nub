
<?php $__env->startSection('content-header'); ?>
    <h1 style="font-family: 'Arial Narrow';">
        Gallery
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-pie-chart"></i> Dashboard</a></li>
        <li class="active">gallery</li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-12">
                            <a target="_blank" href="<?php echo e(asset($gallery->image)); ?>">
                                <img class="img-fluid rounded img-thumbnail"
                                     src="<?php echo e(asset($gallery->image)); ?>" alt="User profile picture">
                            </a>
                        </div>
                        <div class="col-md-12">
                            <table class="table table-bordered table-striped" style="margin-top: 12px">
                                <tr>
                                    <th style="width: 20%">Title</th>
                                    <td style="width: 80%">
                                        <b style="color: orangered"><?php echo e($gallery->title); ?></b>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        <?php if($gallery->status == 1): ?>
                                            <span class="badge badge-success" style="background: darkgreen">Active</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger" style="background: darkred">In Active</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th style="width: 20%">Description</th>
                                    <td><?php echo $gallery->description; ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                </div>
                <div class="col-md-8">
                  <div class="row">
                      <?php $__currentLoopData = $gallery_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="col-md-4" style="margin: 11px 0 11px 0">
                              <a target="_blank" href="<?php echo e(asset($img->image)); ?>">
                                  <img class="img-fluid rounded img-thumbnail"
                                       src="<?php echo e(asset($img->image)); ?>" alt="User profile picture">
                              </a>
                          </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
                <!-- /.col -->
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#side-gallery").addClass('active');
            $("#side-gallery").addClass('active-sidebar');
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\newsbox-nub\resources\views/back-end/gallery/show.blade.php ENDPATH**/ ?>