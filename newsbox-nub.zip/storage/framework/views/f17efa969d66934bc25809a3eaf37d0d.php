<div class="pull-right hidden-xs">
    <b>Version</b> 1
</div>
<strong>Date: <?php echo e(\Carbon\Carbon::now()->format('d-M-Y')); ?>

    Author: <a href="https://www.facebook.com/messages/t/100003143825506">Asif Anam Khan - 01643734728 </a>.</strong> All rights
reserved.<?php /**PATH D:\laragon\www\newsbox-nub\resources\views/back-end/layouts/footer.blade.php ENDPATH**/ ?>