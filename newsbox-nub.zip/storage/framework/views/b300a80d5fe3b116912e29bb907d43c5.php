<div class="row" style="margin-bottom: 5px">
    <div class="col-md-3">
        <label for="">Date</label>
        <input type="text" id="date" class="form-control datepicker" placeholder="">
    </div>
    <div class="col-md-3">
        <label for="">Category</label>
        <select name="" id="category_id" class="form-control select2">
            <option value="">Select</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-3">
        <label for="">Type</label>
        <select name="type" id="type" class="form-control select2">
            <option value="">Select</option>
            <?php $__currentLoopData = $news_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($news_type->id); ?>"><?php echo e($news_type->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-3">
        <label for="">Title</label>
        <input type="text" id="title" class="form-control" placeholder="">
    </div>
    <div class="col-md-12" style="margin-top: 5px">
        <button id="search-btn" style="float: right" class="btn btn-sm btn-grad">Search</button>
    </div>
</div>
<table style="width: 100%" class="table table-responsive table-striped data-table-news" id="table">
    <thead class="table-header-background" style=";">
    <tr class="" style="text-align:center; ">
        <th style="width: 8%">SL</th>
        <th style="width: 13%">Image</th>
        <th style="width: 10%">Date</th>
        <th style="width: 25%">Title</th>
        <th style="width: 12%">Category</th>
        <th style="width: 12%">Type</th>
        <th style="width: 10%">Action</th>
    </tr>
    </thead>
</table>

<script>
    var slide_type = "<?php echo e($type); ?>"
    var slide_id = "<?php echo e($slide_id); ?>"
    var news_datatable = $('.data-table-news').DataTable({
        order: [],
        lengthMenu: [[10, 20, 30, 50, 100, -1], [10, 20, 30, 50, 100, "All"]],
        processing: true,
        responsive: true,
        searching: false,
        serverSide: true,
        language: {
            processing: '<i class="ace-icon fa fa-spinner fa-spin bigger-500" style="font-size:60px;"></i>'
        },
        scroller: {
            loadingIndicator: false
        },
        pagingType: "full_numbers",

        ajax: {
            url: "<?php echo e(route('add-news-to-slide')); ?>",
            type: "get",
            data: function (d) {
                d.date = $('#date').val(),
                d.category_id = $('#category_id').val(),
                d.type = $('#type').val(),
                d.title = $('#title').val(),
                d.slide_type = slide_type,
                d.slide_id = slide_id
            }
        },

        columns: [
            {data: "DT_RowIndex", name: "DT_RowIndex", orderable: false,},
            {data: 'image', name: 'image', orderable: false},
            {data: 'date', name: 'date', orderable: true},
            {data: 'title', name: 'title', orderable: true},
            {data: 'category_id', name: 'category_id', orderable: true},
            {data: 'type', name: 'type', orderable: true},
            {data: 'action', searchable: false, orderable: false}

            //only those have manage_user permission will get access

        ],
    });

    $("#search-btn").on('click', function () {
        news_datatable.clear().draw();

    });

</script><?php /**PATH D:\laragon\www\newsbox-nub\resources\views/back-end/slide/add-news.blade.php ENDPATH**/ ?>