<!-- Social Follow Start -->
<div class="mb-3 <?php if(\Request::route()->getName() != 'home'): ?> mt-5 pt-3 <?php endif; ?>">
    <div class="section-title mb-0">
        <h4 class="m-0 text-uppercase font-weight-bold">Follow Us</h4>
    </div>
    <div class="bg-white border border-top-0 p-3">
        <?php
            $social_links = \Illuminate\Support\Facades\DB::table('social_links')
            ->get()
        ?>

        <?php $__currentLoopData = $social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="" class="d-block w-100 text-white text-decoration-none mb-3"
               style="background: <?php echo e($social_link->color); ?>;">
                <i class="fab <?php echo e($social_link->icon); ?><?php if($social_link->name == 'Facebook'): ?>-f <?php endif; ?>
                 text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
                <span class="font-weight-medium">12,345 Fans</span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- Social Follow End -->

<!-- Ads Start -->
<div class="mb-3">
    <div class="section-title mb-0">
        <h4 class="m-0 text-uppercase font-weight-bold">Advertisement</h4>
    </div>
    <div class="bg-white text-center border border-top-0 p-3">
        <a href=""><img class="img-fluid" src="<?php echo e(asset('public/front-end/img/news-800x500-2.jpg')); ?>" alt=""></a>
    </div>
</div>
<!-- Ads End -->

<!-- Popular News Start -->
<?php
    $trending_news = \Illuminate\Support\Facades\DB::table('news')
                ->where('news.type',1)
                ->leftjoin('news_categories', 'news.category_id', '=', 'news_categories.id')
                ->orderBy('news.id', 'DESC')
                ->select(['news.*','news_categories.name as news_cat_name'])
                ->take(5)->get();
?>

<?php if(\Request::route()->getName() == 'home'): ?>
    <div class="mb-3">
        <div class="section-title mb-0">
            <h4 class="m-0 text-uppercase font-weight-bold">Trending News</h4>
        </div>
        <div class="bg-white border border-top-0 p-3">
            <?php $__currentLoopData = $trending_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trending_new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
                    <img class="img-fluid" style="height: 110px; width: 110px" src="<?php echo e(asset($trending_new->image)); ?>"
                         alt="">
                    <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                        <div class="mb-2">
                            <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2"
                               href=""><?php echo e($trending_new->news_cat_name); ?></a>
                            <a class="text-body"
                               href=""><small><?php echo e(\Carbon\Carbon::parse($trending_new->date)->format('M d, Y')); ?></small></a>
                        </div>
                        <?php
                            $latest_title = substr($trending_new->title,0, 25);
                        ?>
                        <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href=""><?php echo e($latest_title); ?>

                            ...</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
<?php endif; ?>

<!-- Popular News End -->

<!-- Newsletter Start -->
<div class="mb-3">
    <div class="section-title mb-0">
        <h4 class="m-0 text-uppercase font-weight-bold">Newsletter</h4>
    </div>
    <div class="bg-white text-center border border-top-0 p-3">
        <p>Subscribe tog get latest news in email</p>
        <form action="<?php echo e(route('newsletter.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-group mb-2" style="width: 100%;">
                <input type="text" name="email" class="form-control form-control-lg" placeholder="Your Email">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-primary font-weight-bold px-3">Sign Up</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Newsletter End -->

<!-- Tags Start -->
<?php if(\Request::route()->getName() == 'home'): ?>
    <div class="mb-3">
        <div class="section-title mb-0">
            <h4 class="m-0 text-uppercase font-weight-bold">Tags</h4>
        </div>
        <div class="bg-white border border-top-0 p-3">
            <div class="d-flex flex-wrap m-n1">
                <?php $__currentLoopData = $news_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="" class="btn btn-sm btn-outline-secondary m-1"><?php echo e($news_category->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
<?php endif; ?>
<!-- Tags End -->
<?php /**PATH D:\laragon\www\newsbox-nub\resources\views/front-end/layouts/sidebar.blade.php ENDPATH**/ ?>