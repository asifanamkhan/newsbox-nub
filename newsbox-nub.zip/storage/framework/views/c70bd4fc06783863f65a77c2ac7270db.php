
<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5 pt-3">
        <div class="container">

            <div class="section-title mb-0">
                <h4 class="m-0 text-uppercase font-weight-bold">Latest news</h4>
            </div>
            <div class="bg-white border border-top-0 p-4 mb-3">
                <div class="row">
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <div class="d-flex col-md-6 align-items-center bg-white mb-3" style="height: 110px;">
                            <img class="img-fluid" style="height: 110px; width: 110px" src="<?php echo e(asset($latest->image)); ?>" alt="">
                            <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                                <div class="mb-2">
                                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href=""><?php echo e($latest->news_cat_name); ?></a>
                                    <a class="text-body" href=""><small><?php echo e(\Carbon\Carbon::parse($latest->date)->format('M d, Y')); ?></small></a>
                                </div>
                                <?php
                                    $latest_title = substr($latest->title,0, 25);
                                     $latest_desc = substr($latest->short_description,0, 70);
                                ?>
                                <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="<?php echo e(route('single-news-details',$latest->id)); ?>"><?php echo e($latest_title); ?> ...</a>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front-end.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\newsbox-nub\resources\views/front-end/pages/news/category-wise-details.blade.php ENDPATH**/ ?>