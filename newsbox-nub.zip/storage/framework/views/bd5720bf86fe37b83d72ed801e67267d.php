<?php $__env->startSection('content-header'); ?>
    <h1 style="font-family: 'Arial Narrow';">
        Social Links
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-pie-chart"></i> Settings</a></li>
        <li class="active">social media links</li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="box">
        <div class="box-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width: 4%">Icon</th>
                        <th style="width: 10%">Social Media</th>
                        <th style="width: 58%">Link</th>
                        <th style="width: 20%">Number of followers</th>
                        <th style="width: 8%">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(route('social-link.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <tr>
                            <td style="">
                                <div style="background:<?php echo e($value->color); ?> ; color: white; font-size: 20px; padding: 1px; border-radius: 2px; text-align: center">
                                    <i class="fa <?php echo e($value->icon); ?>"></i>
                                </div>
                            </td>
                            <td>
                                <input name="name" type="text" readonly  class="form-control" value="<?php echo e($value->name); ?>">
                                <input name="id" type="hidden" readonly  class="form-control" value="<?php echo e($value->id); ?>">
                            </td>
                            <td>
                                <input required name="link" type="text" class="form-control" value="<?php echo e($value->link); ?>">
                            </td>
                            <td>
                                <input name="num_of_follower" type="number" class="form-control" value="<?php echo e($value->num_of_follower); ?>">
                            </td>
                            <td>
                                <button class="btn btn-sm btn-primary">
                                    <i class="fa fa-check"></i> update
                                </button>
                            </td>
                        </tr>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#side-settings").addClass('active');
            $("#side-social-link").addClass('active');
            $("#side-social-link").addClass('active-sidebar');
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\newsbox-nub\resources\views/back-end/settings/social-link/index.blade.php ENDPATH**/ ?>