<div class="container-fluid p-0">
    <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-2 py-lg-0 px-lg-5">
        <a href="<?php echo e(route('home')); ?>" class="navbar-brand d-block d-lg-none">
            <h1 class="m-0 display-4 text-uppercase text-primary">NUB<span class="text-white font-weight-normal">NEWS</span></h1>
        </a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between px-0 px-lg-3" id="navbarCollapse">
            <div class="navbar-nav mr-auto py-0">
                <a href="<?php echo e(route('home')); ?>" class="nav-item nav-link active">Home</a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">News</a>
                    <div class="dropdown-menu rounded-0 m-0">
                        <?php $__currentLoopData = $news_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('cat-wise-news-details',$news_category->id)); ?>" class="dropdown-item"><?php echo e($news_category->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <a href="category.html" class="nav-item nav-link">About us</a>
                <a href="contact.html" class="nav-item nav-link">Gallery</a>
                <a href="contact.html" class="nav-item nav-link">Events</a>
                <a href="contact.html" class="nav-item nav-link">Achievements</a>

            </div>
            <div class="input-group ml-auto d-none d-lg-flex" style="width: 100%; max-width: 300px;">
                <input type="text" class="form-control border-0" placeholder="Keyword">
                <div class="input-group-append">
                    <button class="input-group-text bg-primary text-dark border-0 px-3"><i
                                class="fa fa-search"></i></button>
                </div>
            </div>
        </div>
    </nav>
</div><?php /**PATH D:\laragon\www\newsbox-nub\resources\views/front-end/layouts/nav.blade.php ENDPATH**/ ?>