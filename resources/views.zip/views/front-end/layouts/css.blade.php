<style>
    .navbar-dark .navbar-nav .nav-link:hover, .navbar-dark .navbar-nav .nav-link.active{
        color: white;
        background: #0F5586;
    }

    .badge-primary{
        background: #0F5586;
        color: white;
    }

    .badge-primary:hover {
        background: #0F5586;
        color: white;
    }

    .bg-primary {
        background-color: #0F5586 !important;
        color: white !important;
    }
    .main-carousel .owl-dot.active{
        background-color: #0F5586 !important;
    }
    .section-title {
        border-left: 5px solid #0F5586;
    }

    .btn-primary {
        color: white;
        background-color: #0F5586;
        border-color: #0f5a83;

    }
</style>